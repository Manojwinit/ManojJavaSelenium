package driverManagerFactory;

public enum DriverType {

	CHROME,FIREFOX,EDGE,IE;
}
