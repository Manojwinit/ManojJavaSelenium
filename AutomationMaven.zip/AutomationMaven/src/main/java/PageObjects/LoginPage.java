package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	private By userNameTextBox = By.id("txtUsername");
	private By passwordTextBox = By.id("txtPassword");
	private By loginButton = By.id("btnLogin");

	public void login(String userName, String password) {
		this.setUserName(userName);
		this.setPassword(password);
	}

	public void setUserName(String userName) {
		driver.findElement(userNameTextBox);
	}

	public void setPassword(String password) {
		driver.findElement(passwordTextBox);
	}

	public void clickLogin() {
		driver.findElement(loginButton);
	}
}
