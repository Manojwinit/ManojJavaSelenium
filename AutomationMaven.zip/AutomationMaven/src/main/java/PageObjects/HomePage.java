package PageObjects;

import org.openqa.selenium.By;

import PageObjects.HomePage;
import TestSetUp.Base;
import TestUtils.BrowserActions;
import TestUtils.WaitUtil;

public class HomePage extends Base {

	By logoutLink = By.id("lbLogout");
	By clickHereLink = By.xpath("//a[@href='Login.aspx']");

	public void logout() {
		BrowserActions.WaitAndclick(logoutLink);
		WaitUtil.Sleep5();
	}

	public void clickHereToLoginAgain() {
		BrowserActions.WaitAndclick(clickHereLink);
	}
}
