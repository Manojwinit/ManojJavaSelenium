package Arla.AutomationMaven;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import PageObjects.LoginPage;
import driverManagerFactory.DriverManager;
import driverManagerFactory.DriverManagerFactory;
import driverManagerFactory.DriverType;

public class LoginPageTest {
	DriverManager driverManager;
	WebDriver driver;
	LoginPage loginPage;

	@BeforeClass
	public void setUp() {
		driverManager = DriverManagerFactory.getDriveManager(DriverType.CHROME);
		driver = driverManager.getWebDriver();
		driver.get("https://dev-arlavansales.winitsoftware.com/pages/Login.aspx");
		driver.manage().window().maximize();
	}

	@Test
 public void loginTest() {
 loginPage = new LoginPage(driver);
 loginPage.login("admin", "1234");
 //assertEquals(loginPage.getLoginErrorMessage(), "Invalid username or password");
}
}